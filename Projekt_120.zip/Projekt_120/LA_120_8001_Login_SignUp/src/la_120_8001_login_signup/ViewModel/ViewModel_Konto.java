/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package la_120_8001_login_signup.ViewModel;

/**
 *
 * @author k_tur
 */
public class ViewModel_Konto {
    
}
